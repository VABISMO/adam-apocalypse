import React, { useState, useMemo, useEffect } from 'react';
import { createRoot } from 'react-dom/client';
import * as Astronomy from 'astronomy-engine';

// ====== Sefer Yetzirah ======
const SIGNS = ['Aries','Tauro','Géminis','Cáncer','Leo','Virgo','Libra','Escorpio','Sagitario','Capricornio','Acuario','Piscis'];
const SIMPLE = {
  'Aries':['ה','Heh',5], 'Tauro':['ו','Vav',6], 'Géminis':['ז','Zayin',7], 'Cáncer':['ח','Chet',8],
  'Leo':['ט','Tet',9], 'Virgo':['י','Yod',10], 'Libra':['ל','Lamed',30], 'Escorpio':['נ','Nun',50],
  'Sagitario':['ס','Samekh',60], 'Capricornio':['ע','Ayin',70], 'Acuario':['צ','Tzaddi',90], 'Piscis':['ק','Qoph',100]
};
const LETTER_TO_SIGN = {}; Object.entries(SIMPLE).forEach(([s,[he]])=>{LETTER_TO_SIGN[he]=s});
const DOUBLES = {
  'Saturno':['ב','Bet',2], 'Júpiter':['ג','Gimel',3], 'Marte':['ד','Dalet',4], 'Sol':['כ','Kaph',20],
  'Venus':['פ','Pe',80], 'Mercurio':['ר','Resh',200], 'Luna':['ת','Tav',400]
};
const MOTHERS = [
  ['א','Aleph','aire · Draco',268],
  ['מ','Mem','agua · Osa Menor',89],
  ['ש','Shin','fuego · Casiopea',38]
];
const BODIES = ['Saturno','Júpiter','Marte','Sol','Venus','Mercurio','Luna','Urano','Neptuno','Plutón'];
const AE_NAME = {Saturno:'Saturn',Júpiter:'Jupiter',Marte:'Mars',Sol:'Sun',Venus:'Venus',Mercurio:'Mercury',Luna:'Moon',Urano:'Uranus',Neptuno:'Neptune',Plutón:'Pluto'};
const GLYPH = {Sol:'☉',Luna:'☽',Mercurio:'☿',Venus:'♀',Marte:'♂',Júpiter:'♃',Saturno:'♄',Urano:'♅',Neptuno:'♆',Plutón:'♇'};
const WEEK = [['Domingo','Sol'],['Lunes','Luna'],['Martes','Marte'],['Miércoles','Mercurio'],['Jueves','Júpiter'],['Viernes','Venus'],['Sábado','Saturno']];

const FIN2REG = {'ן':'נ','ץ':'צ','ך':'כ','ם':'מ','ף':'פ'};
const REG2FIN = {'נ':'ן','צ':'ץ','כ':'ך','מ':'ם','פ':'ף'};
const SIMPLE_LETTERS = new Set(Object.values(SIMPLE).map(x=>x[0]));
const GV = {א:1,ב:2,ג:3,ד:4,ה:5,ו:6,ז:7,ח:8,ט:9,י:10,כ:20,ל:30,מ:40,נ:50,ס:60,ע:70,פ:80,צ:90,ק:100,ר:200,ש:300,ת:400};
function norm(s){ return [...s].map(c=>FIN2REG[c]||c).join(''); }
function displayHe(s){ if(!s) return s; const last=s[s.length-1]; const f=REG2FIN[last]; return f ? s.slice(0,-1)+f : s; }
function gematria(s){ return [...s].reduce((a,c)=>a+(GV[c]||0),0); }
function simpleSet(cons){ const s=new Set(); for(const c of cons) if(SIMPLE_LETTERS.has(c)) s.add(c); return s; }
function formable(cons, occ){ for(const c of simpleSet(cons)) if(!occ.has(c)) return false; return true; }
function readableWords(occ, LEX, ES){
  const res=[], seen=new Set();
  for(const [cons,trans,gloss,pos] of LEX){
    if(seen.has(cons)) continue;
    if(formable(cons, occ)){
      seen.add(cons);
      const simp=[...simpleSet(cons)].sort().join('');
      res.push({he:cons, disp:displayHe(cons), translit:trans, gloss, es:ES[cons]||null, pos, len:cons.length, gem:gematria(cons), simp});
    }
  }
  res.sort((a,b)=> b.len-a.len || a.gem-b.gem || (a.he<b.he?-1:1));
  return res;
}

function skyAt(dateStr){
  const d = new Date(dateStr + 'T12:00:00Z');
  return BODIES.map(b=>{
    const v = Astronomy.GeoVector(Astronomy.Body[AE_NAME[b]], d, true);
    const lon = Astronomy.Ecliptic(v).elon;
    let si = Math.floor(lon/30) % 12; if(si<0) si+=12;
    return { body:b, lon, sign:SIGNS[si], deg: lon - si*30, boundary:(lon-si*30)<1||(lon-si*30)>29 };
  });
}
function occupiedLetters(rows){ const s=new Set(); rows.forEach(r=>s.add(SIMPLE[r.sign][0])); return s; }
function bySign(rows){ const m={}; rows.forEach(r=>{(m[r.sign]=m[r.sign]||[]).push(r)}); return m; }

const GENESIS = [
  ['בראשית','en el principio'],['ברא','creó'],['אלהים','Dios'],['את','(acusativo: a)'],
  ['השמים','los cielos'],['ואת','y (acusativo)'],['הארץ','la tierra']
];
function genesisReadable(occ){ return GENESIS.every(([w])=>formable(norm(w), occ)); }
const GEN_TOTAL = 2701;

const PREC = 50.29/3600, AGE = 30/PREC, FULL = 360/PREC, AYANAMSIS = 24.18;
const EQUINOX_LON = (360 - AYANAMSIS) % 360;
function ageBoundaries(){
  const out=[];
  for(let i=0;i<12;i++){
    const hi=(i+1)*30; let dt=(EQUINOX_LON-hi)/PREC;
    while(dt>FULL/2) dt-=FULL; while(dt<-FULL/2) dt+=FULL;
    const start=2024+dt; out.push({sign:SIGNS[i], he:SIMPLE[SIGNS[i]][0], start, end:start+AGE});
  }
  return out;
}
function yrLabel(y){ return y<0 ? Math.round(-y)+' a.C.' : Math.round(y)+' d.C.'; }

// 6 ventanas Neptuno(Aries)∧Plutón(Acuario) — ciclo sinódico ~491 a (calculadas en el artículo)
const ERA_WINDOWS = [
  {w:'-427 a -417 a.C.', ev:'Edad Axial (Platón n. 427; redacción Torá; Buda)'},
  {w:'61–73 d.C.', ev:'Destrucción del Segundo Templo (70); judaísmo rabínico; ruptura cristiana'},
  {w:'552–565', ev:'Justiniano; Santa Sofía; cierre del Talmud; pre-Islam'},
  {w:'1043–1056', ev:'Cisma de Oriente/Occidente (1054)'},
  {w:'1535–1547', ev:'Reforma (1517); Copérnico, De revolutionibus (1543)'},
  {w:'2025–2038', ev:'ventana actual'},
];

function SkyMap({rows, occ, yhvhOk, genesisOk}){
  const C=220, R=196, Rp=120;
  const pt=(lon,r)=>{const a=lon*Math.PI/180;return [C+r*Math.sin(a), C-r*Math.cos(a)];};
  const MOTHER_LON=[['א','Draco',268],['מ','Osa Menor',89],['ש','Casiopea',38]];
  const signCount={}; rows.forEach(r=>{signCount[r.sign]=(signCount[r.sign]||0)+1;});
  const yod = rows.find(r=>r.sign==='Virgo');
  const heh = rows.find(r=>r.sign==='Aries');
  const vav = rows.find(r=>r.sign==='Tauro');
  const order=[];
  if(yod) order.push({r:yod,l:'י'});
  if(heh) order.push({r:heh,l:'ה'});
  if(vav) order.push({r:vav,l:'ו'});
  if(heh) order.push({r:heh,l:'ה'});
  const contrib=new Set(order.map(o=>o.r.body));
  const pathStr = order.map((o,i)=>{const [x,y]=pt(o.r.lon,Rp);return (i?'L':'M')+x.toFixed(1)+' '+y.toFixed(1);}).join(' ');
  return (
    <svg viewBox="0 0 440 440" width="340" height="340" style={{maxWidth:'100%'}} role="img" aria-label={`Mapa estelar: ${occ.size} signos ocupados; יהוה ${yhvhOk?'legible':'no legible'}; Génesis ${genesisOk?'legible':'no legible'}`}>
      <circle cx={C} cy={C} r={R} fill="#0e1320" stroke="#283145" strokeWidth="2"/>
      <circle cx={C} cy={C} r={Rp+22} fill="none" stroke="#1c2333" strokeWidth="1"/>
      {SIGNS.map((s,i)=>{
        const [x0,y0]=pt(i*30,R), [x1,y1]=pt((i+1)*30,R);
        const on=occ.has(SIMPLE[s][0]);
        return <path key={s} d={`M ${C} ${C} L ${x0} ${y0} A ${R} ${R} 0 0 0 ${x1} ${y1} Z`} fill={on?'rgba(127,176,255,0.10)':'transparent'} stroke={on?'#3a4762':'#283145'} strokeWidth="0.7"/>;
      })}
      {SIGNS.map((s,i)=>{
        const [lx,ly]=pt(i*30+15, R-20); const [nx,ny]=pt(i*30+15, R-3);
        const on=occ.has(SIMPLE[s][0]), n=signCount[s]||0;
        return <g key={s}>
          <text x={lx} y={ly} textAnchor="middle" dominantBaseline="middle" fontSize="21" fill={on?'#cfe0ff':'#5a647a'}>{SIMPLE[s][0]}</text>
          <text x={nx} y={ny} textAnchor="middle" dominantBaseline="middle" fontSize="8.5" fill={on?'#8aa0c0':'#424b5e'}>{s}{n>1?(' ·×'+n):''}</text>
        </g>;
      })}
      {order.length>=2 && <path d={pathStr} fill="none" stroke="#e8c87a" strokeWidth="2.4" strokeDasharray={yhvhOk?'none':'5 4'} opacity="0.9" strokeLinejoin="round"/>}
      {rows.map(r=>{
        const [px,py]=pt(r.lon,Rp);
        if(contrib.has(r.body)){
          return <g key={r.body}>
            <circle cx={px} cy={py} r="12" fill="#e8c87a" stroke="#fff3d0" strokeWidth="1"/>
            <text x={px} y={py} textAnchor="middle" dominantBaseline="middle" fontSize="14" fill="#0b0e14" fontWeight="bold">{order.find(o=>o.r.body===r.body).l}</text>
          </g>;
        }
        return <g key={r.body}>
          <circle cx={px} cy={py} r="8.5" fill="#131826" stroke="#7fb0ff" strokeWidth="1.2"/>
          <text x={px} y={py} textAnchor="middle" dominantBaseline="middle" fontSize="12" fill="#7fb0ff">{GLYPH[r.body]}</text>
          {r.boundary && <circle cx={px} cy={py} r="11.5" fill="none" stroke="#ffcf6a" strokeWidth="1" strokeDasharray="2 2" opacity="0.8"/>}
        </g>;
      })}
      <text x={C} y={16} textAnchor="middle" fontSize="11" fill={yhvhOk?'#e8c87a':'#ff8a8a'}>יהוה {yhvhOk?'✓':'✗'}</text>
      <text x={C} y={30} textAnchor="middle" fontSize="9.5" fill={genesisOk?'#6fe0a0':'#ff8a8a'}>Génesis {genesisOk?'✓':'✗'}</text>
      <circle cx={C} cy={C} r="32" fill="#0e1320" stroke="#2a3346" strokeWidth="1" strokeDasharray="3 3"/>
      {MOTHER_LON.map(([h,con,lon])=>{
        const [lx,ly]=pt(lon,18); const [nx,ny]=pt(lon,38); const [ox,oy]=pt(lon,R-24); const [sx,sy]=pt(lon,44);
        return <g key={h}>
          <line x1={sx} y1={sy} x2={ox} y2={oy} stroke="#33405a" strokeWidth="0.6" strokeDasharray="2 3" opacity="0.55"/>
          <text x={lx} y={ly} textAnchor="middle" dominantBaseline="middle" fontSize="19" fill="#9aa6bd">{h}</text>
          <text x={nx} y={ny} textAnchor="middle" dominantBaseline="middle" fontSize="5.6" fill="#5d6883">{con}</text>
        </g>;
      })}
      <text x={C} y={C+34} textAnchor="middle" fontSize="6.5" fill="#525d72">3 madres · eje fijo circumpolar</text>
    </svg>
  );
}

function App(){
  const today = '2026-08-07';
  const [lex, setLex] = useState(null);
  const [lexErr, setLexErr] = useState(null);
  const [date, setDate] = useState(today);
  const [genYear, setGenYear] = useState(2026);
  const [genData, setGenData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [showAll, setShowAll] = useState(false);
  const [q, setQ] = useState('');

  useEffect(()=>{ fetch('lexicon.json').then(r=>{ if(!r.ok) throw new Error('HTTP '+r.status); return r.json(); }).then(setLex).catch(e=>setLexErr(e.message)); },[]);

  const rows = useMemo(()=>skyAt(date),[date]);
  const occ = useMemo(()=>occupiedLetters(rows),[rows]);
  const occSigns = useMemo(()=>new Set(rows.map(r=>r.sign)),[rows]);
  const bs = useMemo(()=>bySign(rows),[rows]);
  const yhvhOk = occ.has('י') && occ.has('ה') && occ.has('ו');
  const genesisOk = genesisReadable(occ);
  const words = useMemo(()=> lex ? readableWords(occ, lex.lexicon, lex.esGloss) : [], [occ, lex]);
  const sentence = rows.map(r=>SIMPLE[r.sign][0]).join(' ');
  const year = parseInt(date.slice(0,4),10);
  const ages = useMemo(()=>ageBoundaries(),[]);

  function scanYear(y){
    setLoading(true);
    setTimeout(()=>{
      const days=[];
      for(let i=0;i<365;i++){
        const ds=new Date(Date.UTC(y,0,1+i,12,0,0)).toISOString().slice(0,10);
        if(genesisReadable(occupiedLetters(skyAt(ds)))) days.push(ds);
      }
      setGenData({year:y, days:new Set(days), list:days}); setLoading(false);
    },20);
  }
  useEffect(()=>{ if(lex) scanYear(genYear); },[genYear, lex]);
  function step(n){ const d=new Date(date+'T12:00:00Z'); d.setUTCDate(d.getUTCDate()+n); setDate(d.toISOString().slice(0,10)); }
  function stepYear(n){ setGenYear(genYear+n); }

  const qn = q.trim().toLowerCase();
  const filtered = qn ? words.filter(w => (w.es||w.gloss||'').toLowerCase().includes(qn) || w.translit.toLowerCase().includes(qn) || w.disp.includes(q.trim()) ) : words;
  const alwaysCount = words.filter(w=>!w.simp).length;

  if(lexErr) return <div className="panel"><h2>Error</h2><p>No se pudo cargar lexicon.json ({lexErr}). Sirve el directorio con un servidor HTTP (python3 -m http.server 8008) y abre la página vía http://127.0.0.1:8008/.</p></div>;
  if(!lex) return <div className="panel"><h2>Cargando lexicón…</h2><p>Leyendo lexicon.json (6045 raíces + glosas ES).</p></div>;

  return (
    <div>
      {/* FECHA */}
      <section className="panel" aria-labelledby="h-fecha"><h2 id="h-fecha">Fecha</h2>
        <div className="controls">
          <button onClick={()=>step(-1)} aria-label="Día anterior">◀ día</button>
          <input type="date" value={date} onChange={e=>setDate(e.target.value)} aria-label="Fecha" />
          <button onClick={()=>step(1)} aria-label="Día siguiente">día ▶</button>
          <button onClick={()=>step(7)} aria-label="Avanzar una semana">+ semana</button>
          <button onClick={()=>setDate(today)} aria-label="Ir a hoy">hoy</button>
          <span className="muted">mediodía UT · posiciones geocéntricas aparentes</span>
        </div>
      </section>

      {/* MAPA */}
      <section className="panel" aria-labelledby="h-mapa">
        <h2 id="h-mapa">Mapa estelar <span className="pill">12 simples</span> <span className={'pill '+(yhvhOk?'ok':'no')}>יהוה {yhvhOk?'✓':'✗'}</span> <span className={'pill '+(genesisOk?'ok':'no')}>Génesis {genesisOk?'✓':'✗'}</span></h2>
        <div className="row">
          <div style={{flex:'0 0 auto'}}><SkyMap rows={rows} occ={occ} yhvhOk={yhvhOk} genesisOk={genesisOk} /></div>
          <div style={{flex:'1 1 240px'}}>
            <div className="muted">La rueda es la eclíptica: 12 signos, cada uno con su letra simple. El sector se <b>resalta</b> cuando tiene un planeta dentro — esa es la simple que se lee hoy. «×N» = N planetas en ese signo (informativo; con la regla de reutilización no hace falta conjunción para repetir una letra). ⚠ = planeta a &lt;1° del límite.</div>
            <div className="note">Hoy: <b>{occSigns.size}</b> signos ocupados, <b>{12-occSigns.size}</b> vacíos. Simples legibles: <b style={{color:'var(--gold)'}}>{[...occ].sort().join(' ')}</b>.</div>
            <div className="note"><span className="he">יהוה</span> (reutilización) se forma con solo 3 signos: <b>י</b>(Virgo)+<b>ה</b>(Aries)+<b>ו</b>(Tauro). La segunda <b>ה</b> reutiliza Aries. Línea dorada: י→ה→ו→ה.</div>
            <div className="note">En el <b>centro</b>, las 3 madres <span className="he">א מ ש</span>: eje fijo circumpolar, cada una <b>enfrente de su constelación</b> (Draco, Osa Menor, Casiopea), unida por una línea a su sector del zodiaco.</div>
          </div>
        </div>
      </section>

      {/* CIELO */}
      <section className="panel" aria-labelledby="h-cielo"><h2 id="h-cielo">El cielo el {date}</h2>
        <table>
          <thead><tr><th>Cuerpo</th><th>Signo</th><th>Grado</th><th>Simple</th><th>Doble</th></tr></thead>
          <tbody>
          {rows.map(r=>(
            <tr key={r.body}>
              <td>{r.body}</td><td>{r.sign}</td>
              <td className="deg">{r.deg.toFixed(2)}° {r.boundary && <span className="boundary">⚠</span>}</td>
              <td className="letter-cell"><span className="he">{SIMPLE[r.sign][0]}</span><br/><span className="muted">{SIMPLE[r.sign][1]}={SIMPLE[r.sign][2]}</span></td>
              <td className="letter-cell">{DOUBLES[r.body] ? <><span className="he" style={{color:'var(--blue)'}}>{DOUBLES[r.body][0]}</span><br/><span className="muted">{DOUBLES[r.body][1]}</span></> : <span className="muted">—</span>}</td>
            </tr>
          ))}
          </tbody>
        </table>
        <div className="muted">Frase leída (letras simples de los 10 cuerpos, lento → rápido):</div>
        <div className="sentence">{sentence}</div>
      </section>

      {/* TRADUCTOR */}
      <section className="panel" aria-labelledby="h-trad">
        <h2 id="h-trad">Traductor — todo lo legible el {date} <span className="pill">{words.length} palabras</span></h2>
        <div className="controls" style={{marginBottom:8}}>
          <input type="text" placeholder="filtrar por glosa o transliteración…" value={q} onChange={e=>setQ(e.target.value)} style={{flex:'1 1 220px'}} aria-label="Filtrar palabras" />
          <span className="muted">{filtered.length} de {words.length} · {alwaysCount} siempre legibles (sin simples)</span>
        </div>
        <div className="muted" style={{marginBottom:8}}>
          Letras disponibles: <b style={{color:'var(--gold)'}}>{[...occ].sort().join(' ')}</b>. <span style={{color:'var(--green)'}}>verde</span>=glosa ES; <span style={{color:'var(--blue)'}}>azul</span>=Strong (EN); <span style={{color:'var(--violet)'}}>morado</span>=siempre legible. Orden: más larga primero.
        </div>
        <div className="tcards">
          {(showAll?filtered:filtered.slice(0,48)).map((w,i)=>(
            <div key={w.he+w.translit+i} className={'tcard'+(w.simp?'':' always')}>
              <div className="the">{w.disp}</div>
              <div className="read">{w.translit}</div>
              <div className="trans" style={{color: w.es?'var(--green)':'var(--blue)'}}>{w.es||w.gloss}</div>
              <div className="g">{w.len} letras · gematria {w.gem}</div>
              <div className="simp">{w.simp ? ('simples: '+[...w.simp].join(' ')) : 'sin simples (siempre)'}</div>
            </div>
          ))}
        </div>
        {filtered.length>48 && <div style={{marginTop:10}}><button className={showAll?'on':''} onClick={()=>setShowAll(s=>!s)}>{showAll?`▲ mostrar 48 de ${filtered.length}`:`▼ ver las ${filtered.length}`}</button></div>}
        <div className="note">Regla de reutilización: una simple está o no está; repasar un signo no añade ni quita letras. Por eso una fecha lee miles de palabras.</div>
      </section>

      {/* CÓMO SE LEE */}
      <section className="panel" aria-labelledby="h-como"><h2 id="h-como">Cómo se lee · regla de reutilización</h2>
        <table>
          <thead><tr><th>Clase</th><th>Letras</th><th>A qué se asignan</th><th>¿Depende de la posición?</th><th>¿Reutilizable?</th></tr></thead>
          <tbody>
            <tr><td>3 madres</td><td>א מ ש</td><td>elementos · Draco / Osa Menor / Casiopea (fijo)</td><td>no</td><td>sí, siempre</td></tr>
            <tr><td>7 dobles</td><td>ב ג ד כ פ ר ת</td><td>los 7 planetas (identidad del planeta)</td><td>no</td><td>sí, siempre</td></tr>
            <tr><td>12 simples</td><td>ה ו ז ח ט י ל נ ס ע צ ק</td><td>los 12 signos zodiacales</td><td><b>sí — si su signo está ocupado</b></td><td>sí (pertenencia)</td></tr>
          </tbody>
        </table>
        <div className="muted" style={{marginTop:10}}>Se lee la simple del signo ocupado. Repetir una simple no necesita conjunción. Las que solo usan madres+dobles (<span className="he">ברא</span>, <span className="he">אב</span>, <span className="he">שבת</span>, <span className="he">אמת</span>) son legibles siempre.</div>
        <div style={{marginTop:10}}><span className="muted">Simples hoy: </span>{SIGNS.map(s=>{const he=SIMPLE[s][0]; return <span key={s} className={'key '+(occ.has(he)?'on':'off')}>{he} {s}</span>;})}</div>
        <div className="note">Vacíos hoy: {SIGNS.filter(s=>!occ.has(SIMPLE[s][0])).map(s=>SIMPLE[s][0]+' ('+s+')').join(', ')||'ninguno'}.</div>
      </section>

      {/* YHVH */}
      <section className="panel" aria-labelledby="h-yhvh"><h2 id="h-yhvh">Las 4 letras de <span className="he">יהוה</span> hoy <span className={'pill '+(yhvhOk?'ok':'no')}>{yhvhOk?'legible':'no legible'}</span></h2>
        <div className="muted" style={{marginBottom:8}}>Con reutilización bastan 3 signos: <b>י</b>(Virgo) + <b>ה</b>(Aries, dos veces) + <b>ו</b>(Tauro). No se necesita conjunción.</div>
        <div className="cards">
          <div className={'card'+(occ.has('י')?'':' missing')}><span className="l">י</span><div style={{fontSize:'.8rem',fontWeight:600}}>Yod</div><div className="src">necesita Virgo</div><div className="src">{bs['Virgo']?.length ? <>de <b>{bs['Virgo'][0].body}</b> · {bs['Virgo'][0].deg.toFixed(1)}°</> : <b>sin planeta</b>}</div></div>
          <div className={'card'+(occ.has('ה')?'':' missing')}><span className="l">ה</span><div style={{fontSize:'.8rem',fontWeight:600}}>Heh (1ª)</div><div className="src">necesita Aries</div><div className="src">{bs['Aries']?.length ? <>de <b>{bs['Aries'][0].body}</b> · {bs['Aries'][0].deg.toFixed(1)}°</> : <b>sin planeta</b>}</div></div>
          <div className={'card'+(occ.has('ו')?'':' missing')}><span className="l">ו</span><div style={{fontSize:'.8rem',fontWeight:600}}>Vav</div><div className="src">necesita Tauro</div><div className="src">{bs['Tauro']?.length ? <>de <b>{bs['Tauro'][0].body}</b> · {bs['Tauro'][0].deg.toFixed(1)}°</> : <b>sin planeta</b>}</div></div>
          <div className={'card'+(occ.has('ה')?'':' missing')}><span className="l">ה</span><div style={{fontSize:'.8rem',fontWeight:600}}>Heh (2ª)</div><div className="src">reutiliza Aries</div><div className="src">{bs['Aries']?.length ? <>mismo <b>{bs['Aries'][0].body}</b></> : <b>sin planeta</b>}</div></div>
        </div>
        <div style={{marginTop:12,padding:'12px 14px',background:'var(--panel2)',borderRadius:8}}>
          {yhvhOk ? <>
            <div className="muted">Hoy se forma ({date}):</div>
            <div style={{fontSize:'1.15rem',color:'var(--gold)'}}>י ({bs['Virgo'][0].body}) → ה ({bs['Aries'][0].body}) → ו ({bs['Tauro'][0].body}) → ה ({bs['Aries'][0].body} reutilizado)</div>
            <div style={{fontSize:'1.15rem',color:'var(--gold)'}}>= <span className="he">יהוה</span> · «el que es / Eterno» · gematria 26</div>
          </> : <>
            <div className="muted">Hoy no se forma <span className="he">יהוה</span>. Faltan:</div>
            {['י:Virgo','ה:Aries','ו:Tauro'].filter(x=>!occ.has(x[0])).map((x,i)=>{const [l,s]=x.split(':'); return <div key={i} className="note" style={{color:'var(--red)'}}><span className="he" style={{fontSize:'1.2rem'}}>{l}</span> → necesita {s} · sin planeta hoy</div>;})}
          </>}
        </div>
      </section>

      {/* GÉNESIS */}
      <section className="panel" aria-labelledby="h-gen">
        <h2 id="h-gen">Génesis 1:1 · <span className="he">בראשית ברא אלהים את השמים ואת הארץ</span> <span className={'pill '+(genesisOk?'ok':'no')}>{genesisOk?'legible el '+date:'no legible el '+date}</span></h2>
        <div className="muted" style={{marginBottom:8}}>Las 7 palabras usan entre todas las simples <b>י ה ל ו צ</b> (Virgo, Aries, Libra, Tauro, Acuario). Legible solo si esos 5 signos están ocupados a la vez — Acuario y Aries anclados por Plutón y Neptuno.</div>
        {GENESIS.map(([w,es],i)=>{const c=norm(w); const ss=[...simpleSet(c)].sort(); const ok=formable(c,occ); return (
          <div key={i} className={'gw '+(ok?'ok':'no')}>
            <span className="w">{displayHe(c)}</span>
            <span className="es" style={{color:ok?'var(--green)':'var(--red)'}}>{es}</span>
            <span className="muted">· gematria {gematria(c)}</span>
            <span style={{marginLeft:'auto'}}>
              {ss.length===0 ? <span style={{color:'var(--violet)'}}>sin simples → siempre</span> : ss.map(l=> <span key={l} className={'key '+(occ.has(l)?'on':'off')} style={{marginLeft:2}}>{l} {LETTER_TO_SIGN[l]}</span>)}
            </span>
          </div>
        );})}
        <div style={{marginTop:10,padding:'10px 14px',background:'var(--panel2)',borderRadius:8}}>
          <span className="muted">Gematria estándar total: </span><b style={{color:'var(--gold)',fontSize:'1.15rem'}}>{GEN_TOTAL}</b>
          <span className="muted"> = 913 + 203 + 86 + 401 + 395 + 407 + 296 · 2701 = 37×73 · triangular 73 · 2701+1072=3773 (palíndromo, pero no selectivo: ~38% de un texto aleatorio también lo cumple)</span>
        </div>
        <div className="note">Génesis se abre en ventanas de ~13 años que recurren cada ~491 años (ciclo sinódico Neptuno–Plutón). Anteriores: −427 a.C. (Edad Axial), 61 d.C. (Templo), 552, 1043 (Cisma), 1535 (Reforma/Copérnico). Actual: 2025–2038.</div>
      </section>

      {/* PREDICCIÓN */}
      <section className="panel" aria-labelledby="h-pred"><h2 id="h-pred">Predicción — días con Génesis legible en {genYear} {loading && <span className="pill">calculando…</span>}</h2>
        <div className="controls" style={{marginBottom:10}}>
          <button onClick={()=>stepYear(-1)} aria-label="Año anterior">◀ {genYear-1}</button>
          <span className="pill">{genYear}</span>
          <button onClick={()=>stepYear(1)} aria-label="Año siguiente">{genYear+1} ▶</button>
          <button onClick={()=>setGenYear(year)} aria-label="Ir al año de la fecha">este año</button>
        </div>
        {genData && <>
          <div className="muted">Total: <b style={{color:'var(--gold)'}}>{genData.list.length}</b> días en {genYear}. Dorado = Génesis legible; contorno verde = fecha elegida ({date}).</div>
          <div className="tl" style={{marginTop:10}} role="img" aria-label={`Calendario de ${genYear}: ${genData.list.length} días legibles`}>
            {Array.from({length: genYear%4===0&&(genYear%100!==0||genYear%400===0)?366:365},(_,i)=>{
              const ds=new Date(Date.UTC(genYear,0,1+i,12)).toISOString().slice(0,10);
              return <div key={i} className={'d'+(genData.days.has(ds)?' on':'')+(ds===date?' cur':'')} title={ds+(genData.days.has(ds)?' · Génesis':'')+(ds===date?' · fecha':'')}></div>;
            })}
          </div>
          <div style={{marginTop:10}}>
            <span className="muted">Fechas con Génesis legible en {genYear}: </span>
            {genData.list.length===0 ? <span className="muted">ninguna este año.</span> : genData.list.map(d=> <span key={d} className="key on click" onClick={()=>setDate(d)}>{d}</span>)}
          </div>
          <div className="legend">Cambia de año con ◀ ▶ para ver el clúster 2028-2029 (Plutón afianzado en Acuario, Neptuno en Aries).</div>
        </>}
      </section>

      {/* SEMANA */}
      <section className="panel" aria-labelledby="h-sem"><h2 id="h-sem">La semana — 7 dobles = 7 planetas = 7 días · dónde está cada uno el {date}</h2>
        <div className="week">
          {WEEK.map(([dia,plan],idx)=>{
            const r=rows.find(x=>x.body===plan);
            const isToday = idx===new Date(date+'T12:00:00Z').getUTCDay();
            return (
              <div key={dia} className={'day'+(isToday?' today':'')}>
                <div className="dn">{dia}{isToday?' · fecha':''}</div>
                <div className="pl">{plan}</div>
                <div className="l">{DOUBLES[plan][0]}</div>
                <div className="pl">{r ? <>{r.sign} <span className="he" style={{fontSize:'1rem'}}>{SIMPLE[r.sign][0]}</span></> : '—'}</div>
              </div>
            );
          })}
        </div>
        <div className="note">Cada planeta (doble) recorre los 12 signos (simples); ese planeta se lee en un signo distinto según el día.</div>
      </section>

      {/* ERAS */}
      <section className="panel" aria-labelledby="h-eras"><h2 id="h-eras">Eras estelares · precesión + ciclo Neptuno–Plutón</h2>
        <div className="muted" style={{marginBottom:10}}>El equinoccio retrocede 50,29″/año → una era precesional por signo, ≈{Math.round(AGE)} años. Equinoccio hoy: <b>{EQUINOX_LON.toFixed(1)}°</b> sidérico (Piscis). Ayanamsa Lahiri 24,18° (2024). Las 6 ventanas de Génesis (Neptuno∈Aries ∧ Plutón∈Acuario) recurren cada ~491 años y coinciden con re-formaciones religioso-lingüísticas mayores:</div>
        <div className="grid2" style={{marginBottom:10}}>
          {ERA_WINDOWS.map((e,i)=>(
            <div key={i} className={'era'+(i===ERA_WINDOWS.length-1?' next':'')}>
              <div className="top"><span><b>{e.w}</b></span><span className="yr">~491 a</span></div>
              <div className="desc">{e.ev}</div>
            </div>
          ))}
        </div>
        <div className="muted" style={{marginBottom:8}}>Tabla de eras precesionales (entrada del equinoccio en cada signo):</div>
        <div className="grid2">
          {ages.map(a=>{
            const now = a.start<=2026 && 2026<a.end;
            const next = a.start>2026 && a.start<2460;
            return (
              <div key={a.sign} className={'era'+(now?' now':'')+(next?' next':'')}>
                <div className="top">
                  <span><span className="ehe he" style={{color:now?'var(--gold)':next?'var(--violet)':'var(--dim)'}}>{a.he}</span> <b>{a.sign}</b></span>
                  <span className="yr">{yrLabel(a.start)} — {yrLabel(a.end)}</span>
                </div>
                <div className="desc">Era de {a.sign} · letra {a.he}. {now?'← era actual':next?'← era entrante':''}</div>
              </div>
            );
          })}
        </div>
        <div style={{marginTop:12,padding:'12px 14px',background:'var(--panel2)',borderRadius:8}}>
          <div className="muted"><b>Activadores lentos hoy ({date}):</b></div>
          <div style={{marginTop:6}}>
            {['Plutón','Neptuno','Urano'].map(p=>{const r=rows.find(x=>x.body===p); const era=ages.find(a=>a.sign===r.sign); return (
              <div key={p} className="note">{GLYPH[p]} <b>{p}</b> en {r.sign} (<span className="he">{SIMPLE[r.sign][0]}</span>{era&&era.start<=2026&&2026<era.end?' · era actual':''}{era&&era.start>2026?' · era entrante':''}) · {r.deg.toFixed(1)}°</div>
            );})}
          </div>
          <div className="note" style={{marginTop:8}}>Plutón en Acuario (<span className="he">צ</span>) y Neptuno en Aries (<span className="he">ה</span>) son los dos anclajes que hacen legible Génesis 1:1. La Era de Acuario (~{yrLabel(ages.find(a=>a.sign==='Acuario').start)}, precesional) y el ciclo sinódico Neptuno–Plutón (~491 a) coinciden ahora.</div>
        </div>
      </section>

      {/* METODOLOGÍA */}
      <section className="panel" aria-labelledby="h-met"><h2 id="h-met">Metodología y alcance</h2>
        <ul className="muted" style={{marginTop:4,lineHeight:1.7}}>
          <li><b>Marco:</b> síntesis hermético-astronómica moderna. El <i>Sefer Yetzirah</i> clásico es lingüística cosmogónica, no oráculo; esta operacionalización es una lectura contemporánea, no práctica cabalística tradicional.</li>
          <li><b>Mapeo simple↔signo:</b> sectores tropicales de 30° iguales (no constelaciones IAU, desiguales y 13). Es una convención simbólica necesaria para la rejilla letra↔signo uno-a-uno. Las madres sí se sitúan frente a sus constelaciones circumpolares reales (Draco, Osa Menor, Casiopea).</li>
          <li><b>Astronomía:</b> astronomy-engine v2.1.19, longitud eclíptica aparente geocéntrica (<code>GeoVector→Ecliptic.elon</code>), mediodía UT.</li>
          <li><b>Lexicón:</b> Strong (OpenScriptures), 6045 raíces consonánticas. Las glosas en <span style={{color:'var(--green)'}}>verde</span> son un overlay curado en español ({Object.keys(lex.esGloss).length}); el resto muestra la glosa Strong en inglés.</li>
          <li><b>Efeméride de Plutón:</b> la precisión degrada fuera de 1700–2200; las ventanas antiguas se apoyan en determinación a nivel de signo (30°), validada por continuidad suave, no por precisión arcominutosa.</li>
          <li><b>Resultados negativos (testados):</b> el espejo-palíndromo 2701→3773 no discrimina a nivel corpus (Génesis 39,0% ≈ Markov 39,7% ≈ uniforme 41,4%, también por bloques de k versos consecutivos); 37/73 no estructuran los eclipses (factorización, periodo, ciclo nodal ~40 estaciones no 37 — verificado empíricamente); los días Génesis no se correlacionan con eclipses (7,5% observado vs 28% esperado, los evitan).</li>
          <li><b>Resultados positivos:</b> 37/73 encajan en el año solar civil (365=73×5; 2701 pentadas=37 años), corroborado por el Haab maya (73×5=365) y el Calendar Round (73 tzolkin); el núcleo Génesis 1 palindroma al 61,3% vs 38,3% del nulo emparejado (p≈8×10⁻³, hipótesis).</li>
          <li><b>Resultados positivos v3.1 (§15b):</b> estructura 37×73 de las 7 palabras de Génesis 1:1 demostrada (23/127 subconjuntos múltiplos de 37, nulo por permutación del multiset, p≈3,1×10⁻⁴); recuento de serie saros por cálculo (152 series, 54–87, mediana 72 — el «73» es estadístico); 7 kameot mágicos = 7 dobles (Mercurio 260 = Tzolkin); Aiq Bekar = gematría decimal-posicional de §2 (puente a los sigilos); 72 ángeles del Shem HaMephorash desde Éxodo (216=6³); heptagrama 7 dobles=7 días (orden caldeo + 24 mod 7 + etimología romance); ayanamsa: dispersión 190 a (descarte tropical robusto); 6 ventanas cadencia 491 a (regularidad p&lt;5×10⁻⁶, hipótesis no causa).</li>
          <li><b>Validación:</b> 86 aserciones en <code>tests.mjs</code> (gematría, kameot, Aiq Bekar, 72 ángeles, Gen1:1 37×73, saros, 231/ABBA, precesión, tetramorfo, sincronía lunar-solar, eclipses, año solar 37/73, legibilidad posicional, equinoccios 2026, cross-cultural Maya/chino/griego, orden caldeo, lexicón) — todas en verde. Scripts: <code>calc_all / calc_37_73 / calc_eclipse_deep / calc_mazzalot / calc_72 / palindrome / calc_phrase / slow_scan / gen_eclipse / calc_crosscultural / calc_magic_squares / calc_sigils / calc_angels72 / calc_gen11_structure / calc_saros_series / calc_ayanamsa / calc_windows_causality / calc_week_chaldean</code>. Véase el artículo <code>lector-del-cielo-articulo.md</code>.</li>
        </ul>
      </section>

      <div className="note" style={{textAlign:'center'}}>
        Posiciones: <a href="https://github.com/cosinekitty/astronomy-engine" target="_blank" rel="noreferrer">astronomy-engine</a> · marco: <a href="https://en.wikipedia.org/wiki/Sefer_Yetirah" target="_blank" rel="noreferrer">Sefer Yetzirah</a> · lexicón: <a href="https://github.com/openscriptures/HebrewLexicon" target="_blank" rel="noreferrer">Strong (OpenScriptures)</a>
      </div>
    </div>
  );
}

const root = document.getElementById('root');
createRoot(root).render(<App/>);